public class GameObject {
    protected String name;
}
